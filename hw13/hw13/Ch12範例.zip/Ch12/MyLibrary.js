function Greeting()
{
  var UserName = prompt("請輸入您的大名", "");
  alert(UserName + "您好！歡迎光臨！");
}
